export default {
    // presets: [require('./wizard.js')],
    theme: {
        extend: {},
    },
    plugins: [],
    corePlugins: {
        preflight: false,
    }
}