(() => {
    const { __, _x, _n, sprintf } = wp.i18n;
});